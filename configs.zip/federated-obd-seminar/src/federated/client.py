from functools import lru_cache
from typing import Any

from flwr.app import ArrayRecord, Context, Message, MetricRecord, RecordDict
from flwr.clientapp import ClientApp

from src.config import load_yaml, set_project_root
from src.experiments.common import (
    ExperimentData,
    fit_normal_real_preprocessing,
    select_normal_real_records,
)
from src.federated.protocol import (
    ARRAYS_KEY,
    CLIENT_INDEX,
    CONFIG_KEY,
    LOCAL_EPOCHS,
    METRICS_KEY,
    NUM_EXAMPLES,
    OPTIMIZER_STATE_KEY,
    PROXIMAL_MU,
    SCALER_KEY,
    SEED,
    SEND_SCALER,
    SERVER_ROUND,
    TRAIN_LOSS,
    TRAIN_SECONDS,
    optimizer_state_from_record,
    optimizer_state_to_record,
    scaler_to_record,
)
from src.models.model import build_model
from src.models.trainer import LocalTrainer, TrainingConfig, set_seed

app = ClientApp()


class FederatedClient:
    """Local training of one client; only weights, metrics, and optionally scaler stats are returned."""

    def __init__(
        self,
        client: str,
        scenario: str,
        data_config: str,
        model_config: str,
        normal_only_real: bool = False,
    ) -> None:
        self.client = client
        data = ExperimentData(data_config)
        self.position = data.client_names(scenario).index(client)
        self.model_config = load_yaml(model_config)
        client_rows = data.client_rows(scenario, client)
        if normal_only_real:
            feature_columns, self.scaler, _ = fit_normal_real_preprocessing(data)
            client_rows = select_normal_real_records(client_rows, data.schema)
        else:
            feature_columns = data.feature_columns
            self.scaler = data.client_scaler(scenario, client)
        self.n_features = len(feature_columns)
        self.features = data.features(client_rows, self.scaler)

    def train(self, message: Message, context: Context) -> Message:
        config = message.content[CONFIG_KEY]
        server_round = int(config[SERVER_ROUND])
        seed = int(config[SEED])
        proximal_mu = float(config[PROXIMAL_MU]) if PROXIMAL_MU in config else 0.0
        step_seed = seed + 1000 * (self.position + 1) + server_round
        set_seed(step_seed)

        model = build_model(self.model_config, self.n_features, seed)
        model.load_state_dict(message.content[ARRAYS_KEY].to_torch_state_dict())
        trainer = LocalTrainer(model, TrainingConfig.from_config(self.model_config["training"]), step_seed)
        if OPTIMIZER_STATE_KEY in context.state:
            trainer.load_optimizer_state(optimizer_state_from_record(context.state[OPTIMIZER_STATE_KEY]))

        reference = [parameter.detach().clone() for parameter in model.parameters()] if proximal_mu > 0 else None
        result = trainer.train(
            self.features, epochs=int(config[LOCAL_EPOCHS]), proximal_mu=proximal_mu, reference_parameters=reference
        )
        context.state[OPTIMIZER_STATE_KEY] = optimizer_state_to_record(trainer.optimizer_state())

        content = RecordDict(
            {
                ARRAYS_KEY: ArrayRecord(model.state_dict()),
                METRICS_KEY: MetricRecord(
                    {
                        NUM_EXAMPLES: result.n_samples,
                        TRAIN_LOSS: result.final_loss,
                        TRAIN_SECONDS: result.seconds,
                        CLIENT_INDEX: self.position,
                    }
                ),
            }
        )
        if bool(config[SEND_SCALER]):
            content[SCALER_KEY] = scaler_to_record(self.scaler, self.client)
        return Message(content=content, reply_to=message)


@lru_cache(maxsize=None)
def _client(
    root: str,
    client: str,
    scenario: str,
    data_config: str,
    model_config: str,
    normal_only_real: bool,
) -> FederatedClient:
    set_project_root(root)
    return FederatedClient(client, scenario, data_config, model_config, normal_only_real)


def _setting(context: Context, key: str) -> Any:
    return context.node_config[key] if key in context.node_config else context.run_config[key]


@app.train()
def train(message: Message, context: Context) -> Message:
    root = str(_setting(context, "project-root"))
    set_project_root(root)
    normal_only_real = context.run_config["normal-only-real"]
    if not isinstance(normal_only_real, bool):
        raise ValueError("normal-only-real must be a boolean")
    client = _client(
        root,
        str(context.node_config["client-id"]),
        str(context.run_config["scenario"]),
        str(context.run_config["data-config"]),
        str(context.run_config["model-config"]),
        normal_only_real,
    )
    return client.train(message, context)
